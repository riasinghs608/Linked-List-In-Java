
package singlelinkedlist;

import java.io.*;

class EmployeeLinkedList {
    
     EmployeeNode listptr,next;
    
    public void addToFront(Employee employee)
    {
        EmployeeNode node=new EmployeeNode(employee);
        node.next=listptr.next;
        listptr=node;
    }
    
    public void printList()
    {
        EmployeeNode current=listptr;
        System.out.println("HEAD-> ");
        while(current!=null)
        {
            System.out.print(current);
            System.out.println(" -> ");
            current=current.getNext();
        }
        System.out.println("null");
    }
    
}


public class SingleLinkedList extends EmployeeLinkedList{

  
    public static void main(String[] args) {
       
        Employee janeJones=new Employee("Jane","Jones",123);
        Employee johnDoe=new Employee("John","Doe",153);
        Employee marySmith=new Employee("Mary","Smith",163);
        Employee mikeWilson=new Employee("Mike","Wilson",193);
        
        EmployeeLinkedList list=new EmployeeLinkedList();
        list.addToFront(janeJones);
        list.addToFront(johnDoe);
        list.addToFront(marySmith);
        list.addToFront(mikeWilson);
        
        list.printList();
        
    }
    
}
