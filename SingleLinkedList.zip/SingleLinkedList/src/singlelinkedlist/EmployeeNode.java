
package singlelinkedlist;


public class EmployeeNode {
    
    private Employee emp;
    private Employee empnode;

    public EmployeeNode(Employee emp, Employee empnode) {
        this.emp = emp;
        this.empnode = empnode;
    }

    EmployeeNode(Employee emp) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Employee getEmp() {
        return emp;
    }

    public Employee getEmpnode() {
        return empnode;
    }

    public void setEmp(Employee emp) {
        this.emp = emp;
    }

    public void setEmpnode(Employee empnode) {
        this.empnode = empnode;
    }
    
    public String toString()
    {
        return emp.toString();
    }

    
}
